# Wiki Revamp — Player-Facing Only

- [ ] Rewrite wikiData.ts: remove all technical content, replace with player-friendly gameplay info
- [ ] Remove chapters: Core Mechanics (tick arch), Edge Cases (server modes), Admin & Moderation (staff tools), Data Persistence (DB schemas), Lifecycle & Release (alpha/beta), Technical Reference (events/RNG/logging)
- [ ] Replace removed chapters with player-relevant topics: Getting Started, How Seasons Work, Earning & Spending, Trading Guide, Leaderboards & Prestige, Tips & Strategy
- [ ] Strip all code snippets, DTOs, reason codes, encoding primitives, server-side logic from remaining content
- [ ] Rewrite remaining content in approachable player-friendly language
- [ ] Update Home page hero text and quick links for player audience
- [ ] Update sidebar categories for player-facing structure
- [ ] Test all pages render correctly
- [ ] Save checkpoint and redeploy
