# Too Many Coins Wiki — Design Brainstorm

## Context
A documentation wiki for the Too Many Coins game design bible and API reference. The content is dense, technical, and hierarchical (15 chapters covering game mechanics, economy, seasons, resources, trading, progression, and technical references). The audience is developers and game designers who need to reference authoritative specifications.

---

<response>
<text>

## Idea 1: "Terminal Ledger" — Brutalist Data Terminal Aesthetic

**Design Movement**: Neo-Brutalist meets retro terminal/hacker aesthetic. Inspired by Bloomberg terminals, old-school MUDs, and monospaced financial dashboards.

**Core Principles**:
1. Information density over decoration — every pixel serves a purpose
2. Monospaced authority — the typeface IS the design
3. Hard edges, no softness — sharp corners, solid borders, zero border-radius
4. Color as signal, not decoration — color only appears to communicate meaning

**Color Philosophy**: Deep charcoal background (#0D0D0D) with phosphor-green (#00FF88) as the primary accent, amber (#FFB800) for warnings/important callouts, and cool gray (#8B9DAF) for secondary text. The palette evokes a financial terminal where color means something specific — green for active/live data, amber for caution, white for neutral content.

**Layout Paradigm**: Fixed left sidebar with collapsible chapter tree (always visible), main content area with a monospaced reading column, and a floating "breadcrumb trail" at the top. Content sections use hard horizontal rules and indented subsections rather than cards. Tables are the primary visual element — styled like spreadsheet cells with visible grid lines.

**Signature Elements**:
1. Blinking cursor indicator next to the current section in the sidebar
2. "Hash-chain" decorative element — each section header shows a truncated hash (like git commits), reinforcing the game's determinism theme
3. ASCII-art dividers between major sections

**Interaction Philosophy**: Keyboard-first navigation. Vim-like shortcuts hinted in the UI. Hover states are instant color inversions (no transitions). Clicking feels like executing a command.

**Animation**: Minimal. Text appears with a typewriter effect on first load only. Section transitions are instant cuts, not fades. The only persistent animation is the blinking cursor in the sidebar.

**Typography System**: JetBrains Mono for everything — headers are simply larger and bolder weights of the same monospace font. Code blocks are indistinguishable from body text except for background color. This creates a "everything is code" feeling appropriate for an API reference.

</text>
<probability>0.06</probability>
</response>

---

<response>
<text>

## Idea 2: "Coin Forge" — Dark Industrial Craft Aesthetic

**Design Movement**: Dark industrial minimalism crossed with numismatic (coin collecting) visual language. Inspired by luxury watch brand websites, mint.com-era financial dashboards, and dark-mode documentation sites like Stripe's.

**Core Principles**:
1. Warm metallics on dark surfaces — gold and bronze tones create a sense of value and weight
2. Layered depth — content floats on distinct elevation planes with subtle shadows
3. Precision typography — sharp contrast between display and body fonts
4. Structured revelation — content unfolds in logical, scannable blocks

**Color Philosophy**: Near-black base (#0A0A0F) with warm gold (#D4A853) as the primary accent, representing coins and value. A secondary cool slate (#64748B) for structural elements. Subtle warm undertones in the dark backgrounds (#12111A) prevent the interface from feeling cold. The gold is used sparingly — only for active states, key terms, and navigation highlights — so it retains its premium feel.

**Layout Paradigm**: Persistent left sidebar with chapter navigation styled as a vertical "mint ledger." The main content area uses a wide reading column with generous margins. Key concepts are presented in "coin card" components — rounded rectangles with a subtle metallic border gradient. Tables use alternating row backgrounds with very subtle warm tinting. A floating table-of-contents rail on the right for the current page.

**Signature Elements**:
1. Coin-inspired circular icons for each chapter category (economy = coin stack, time = hourglass, etc.)
2. Metallic gradient borders on key definition blocks and important callouts
3. "Stamped" section headers — text that appears embossed with a subtle inner shadow

**Interaction Philosophy**: Smooth and deliberate. Hover states reveal additional context through expanding cards. Navigation feels like turning pages in a premium reference book. Sidebar items have a subtle gold underline that slides in on hover.

**Animation**: Refined micro-interactions. Sidebar items slide-reveal with a 200ms ease. Page transitions use a subtle fade-up (150ms). Scroll-triggered section headers animate in with a slight scale-up. Gold accent elements have a subtle shimmer on first appearance. Nothing loops or distracts.

**Typography System**: "Space Grotesk" for headings (geometric, modern, authoritative) paired with "Inter" for body text at 16px with generous 1.7 line-height. Code snippets use "Fira Code" with ligatures. The heading font's geometric quality pairs with the industrial theme while remaining highly readable.

</text>
<probability>0.08</probability>
</response>

---

<response>
<text>

## Idea 3: "Seasonal Atlas" — Cartographic Knowledge Map Aesthetic

**Design Movement**: Modern cartographic/atlas design meets editorial documentation. Inspired by National Geographic's visual storytelling, Figma's documentation, and vintage map typography.

**Core Principles**:
1. Wayfinding as design — the user should always know where they are in the knowledge landscape
2. Warm paper tones create comfort for long reading sessions
3. Typographic hierarchy does the heavy lifting — no need for heavy visual chrome
4. Diagrams and structured data are first-class citizens, not afterthoughts

**Color Philosophy**: Warm parchment base (#FAF6F0) with deep navy (#1B2A4A) as the primary text and accent color. A muted terracotta (#C4654A) for highlights and interactive elements. Sage green (#5B7B6F) for success states and secondary accents. The palette evokes aged maps and scholarly texts — warm, trustworthy, and easy on the eyes for extended reading.

**Layout Paradigm**: Top navigation bar with chapter dropdown menus (like atlas section tabs). Content uses a generous single-column layout with wide margins that contain marginal notes and cross-references (like academic texts). Key definitions sit in bordered "cartouche" boxes inspired by map legend frames. The page feels like a well-typeset reference book rather than a web app.

**Signature Elements**:
1. Compass rose icon as the site logo, with cardinal points representing the four core pillars (Economy, Seasons, Mechanics, Technical)
2. "Map legend" styled definition blocks with a decorative left border and subtle background
3. Dotted connecting lines between related concepts (like trade routes on a map)

**Interaction Philosophy**: Reading-first. Interactions are gentle and supportive — tooltips appear for technical terms, cross-references are inline links with preview hovers. The sidebar is a collapsible "index" that feels like a book's table of contents. Search is prominent and fast.

**Animation**: Understated and purposeful. Page transitions use a gentle 200ms crossfade. Sidebar expansion uses a smooth accordion. Hover tooltips fade in at 150ms. Scroll progress is shown as a thin terracotta line at the top of the viewport. No entrance animations — content is simply present, like a printed page.

**Typography System**: "Libre Baskerville" for headings (classic serif, scholarly authority) paired with "Source Sans 3" for body text (highly readable sans-serif). Code uses "Source Code Pro" to match the body font family. The serif/sans pairing creates a classic editorial feel that signals authority and careful curation.

</text>
<probability>0.07</probability>
</response>
