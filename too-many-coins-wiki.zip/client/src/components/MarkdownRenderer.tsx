/**
 * MarkdownRenderer — Renders wiki markdown content as styled HTML
 * Handles headings, bold, code, tables, lists, blockquotes, links, and horizontal rules
 */
import { useMemo } from "react";

interface MarkdownRendererProps {
  content: string;
  className?: string;
}

function parseMarkdown(md: string): string {
  let html = md;

  // Escape HTML entities (but preserve our markdown)
  html = html.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  // Tables
  html = html.replace(/^(\|.+\|)\n(\|[-| :]+\|)\n((?:\|.+\|\n?)*)/gm, (_match, header: string, _sep: string, body: string) => {
    const headerCells = header.split("|").filter((c: string) => c.trim()).map((c: string) => `<th>${c.trim()}</th>`).join("");
    const rows = body.trim().split("\n").map((row: string) => {
      const cells = row.split("|").filter((c: string) => c.trim()).map((c: string) => {
        let cell = c.trim();
        // Process inline markdown within cells
        cell = processInline(cell);
        return `<td>${cell}</td>`;
      }).join("");
      return `<tr>${cells}</tr>`;
    }).join("");
    return `<table><thead><tr>${headerCells}</tr></thead><tbody>${rows}</tbody></table>`;
  });

  // Code blocks (```)
  html = html.replace(/```(\w*)\n([\s\S]*?)```/g, (_m, _lang, code) => {
    return `<pre><code>${code.trim()}</code></pre>`;
  });

  // Headings
  html = html.replace(/^#### (.+)$/gm, "<h4>$1</h4>");
  html = html.replace(/^### (.+)$/gm, "<h3>$1</h3>");
  html = html.replace(/^## (.+)$/gm, "<h2>$1</h2>");
  html = html.replace(/^# (.+)$/gm, "<h1>$1</h1>");

  // Horizontal rules
  html = html.replace(/^---$/gm, "<hr />");

  // Blockquotes
  html = html.replace(/^&gt; (.+)$/gm, "<blockquote>$1</blockquote>");

  // Ordered lists
  html = html.replace(/^(\d+)\. (.+)$/gm, '<li class="ol-item" data-num="$1">$2</li>');

  // Unordered lists
  html = html.replace(/^- (.+)$/gm, "<li>$1</li>");

  // Wrap consecutive list items
  html = html.replace(/((?:<li class="ol-item"[^>]*>[^<]*<\/li>\n?)+)/g, "<ol>$1</ol>");
  html = html.replace(/((?:<li>(?!class)[^<]*<\/li>\n?)+)/g, "<ul>$1</ul>");

  // Process inline elements
  html = processInlineBlock(html);

  // Paragraphs — wrap lines that aren't already wrapped in block elements
  html = html.replace(/^(?!<[houpbtl]|<\/|<hr|<blockquote|<pre)(.+)$/gm, "<p>$1</p>");

  // Clean up empty paragraphs
  html = html.replace(/<p>\s*<\/p>/g, "");

  return html;
}

function processInline(text: string): string {
  // Inline code
  text = text.replace(/`([^`]+)`/g, "<code>$1</code>");
  // Bold
  text = text.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  // Italic
  text = text.replace(/\*([^*]+)\*/g, "<em>$1</em>");
  return text;
}

function processInlineBlock(html: string): string {
  // Don't process inside <pre> blocks
  const parts = html.split(/(<pre>[\s\S]*?<\/pre>)/g);
  return parts.map((part, i) => {
    if (i % 2 === 1) return part; // pre block, skip
    return processInline(part);
  }).join("");
}

export default function MarkdownRenderer({ content, className = "" }: MarkdownRendererProps) {
  const html = useMemo(() => parseMarkdown(content), [content]);

  return (
    <div
      className={`wiki-prose ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
}
