/**
 * WikiLayout — Main layout with persistent sidebar navigation
 * "Coin Forge" Dark Industrial Aesthetic — Player-Facing Wiki
 */
import { useState, useCallback, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  BookOpen, Compass, Clock, Coins, Sparkles, ArrowLeftRight,
  Trophy, Lock, Award, Users, Shield, Lightbulb, BookText,
  Search, Menu, X, ChevronRight, ChevronDown, Github, ExternalLink
} from "lucide-react";
import { wikiCategories, type WikiChapter, type WikiCategory } from "@/lib/wikiData";

const iconMap: Record<string, React.ComponentType<any>> = {
  BookOpen, Compass, Clock, Coins, Sparkles, ArrowLeftRight,
  Trophy, Lock, Award, Users, Shield, Lightbulb, BookText
};

function ChapterIcon({ name, className }: { name: string; className?: string }) {
  const Icon = iconMap[name] || BookOpen;
  return <Icon className={className} />;
}

interface WikiLayoutProps {
  children: React.ReactNode;
}

export default function WikiLayout({ children }: WikiLayoutProps) {
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(
    new Set(wikiCategories.map(c => c.id))
  );
  const [searchQuery, setSearchQuery] = useState("");

  // Close mobile sidebar on navigation
  useEffect(() => {
    setSidebarOpen(false);
  }, [location]);

  const toggleCategory = useCallback((catId: string) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(catId)) next.delete(catId);
      else next.add(catId);
      return next;
    });
  }, []);

  const currentChapterId = location.startsWith("/chapter/")
    ? location.replace("/chapter/", "")
    : location === "/" ? "what-is-tmc" : "";

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Bar */}
      <header className="sticky top-0 z-50 border-b border-border/60" style={{ background: "oklch(0.12 0.008 260 / 0.95)", backdropFilter: "blur(12px)" }}>
        <div className="flex items-center h-14 px-4 lg:px-6">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="lg:hidden mr-3 p-1.5 rounded-md hover:bg-accent transition-colors"
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>

          <Link href="/" className="flex items-center gap-2.5 no-underline group">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg, oklch(0.78 0.12 80), oklch(0.65 0.10 60))" }}>
              <Coins size={18} className="text-black" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold tracking-tight gold-gradient-text" style={{ fontFamily: "var(--font-heading)" }}>
                Too Many Coins
              </span>
              <span className="text-[10px] uppercase tracking-widest" style={{ color: "oklch(0.50 0.02 260)" }}>
                Wiki
              </span>
            </div>
          </Link>

          <div className="flex-1" />

          {/* Search */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border/60 bg-muted/30 max-w-xs w-full mx-4">
            <Search size={14} style={{ color: "oklch(0.50 0.02 260)" }} />
            <input
              type="text"
              placeholder="Search wiki..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="bg-transparent text-sm outline-none w-full placeholder:text-muted-foreground"
              onKeyDown={e => {
                if (e.key === "Enter" && searchQuery.trim()) {
                  window.location.href = `/search?q=${encodeURIComponent(searchQuery)}`;
                }
              }}
            />
            <kbd className="hidden md:inline-flex text-[10px] px-1.5 py-0.5 rounded border border-border/60 text-muted-foreground">
              /
            </kbd>
          </div>

          <a
            href="https://github.com/TheRealTwizzy/too-many-coins-api"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-2 py-1.5 rounded-md hover:bg-accent"
          >
            <Github size={16} />
            <span className="hidden md:inline">GitHub</span>
          </a>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar Overlay (mobile) */}
        <AnimatePresence>
          {sidebarOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/60 lg:hidden"
              onClick={() => setSidebarOpen(false)}
            />
          )}
        </AnimatePresence>

        {/* Sidebar */}
        <aside
          className={`
            fixed lg:sticky top-14 z-40 h-[calc(100vh-3.5rem)] w-72 border-r border-border/60
            overflow-y-auto transition-transform duration-200 ease-out
            lg:translate-x-0
            ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
          `}
          style={{ background: "oklch(0.115 0.008 260)" }}
        >
          <nav className="py-4 px-3">
            {wikiCategories.map((category) => (
              <div key={category.id} className="mb-2">
                <button
                  onClick={() => toggleCategory(category.id)}
                  className="flex items-center gap-2 w-full px-2 py-2 text-xs font-semibold uppercase tracking-wider rounded-md hover:bg-accent/50 transition-colors"
                  style={{ color: "oklch(0.55 0.02 260)", fontFamily: "var(--font-heading)" }}
                >
                  {expandedCategories.has(category.id) ? (
                    <ChevronDown size={12} />
                  ) : (
                    <ChevronRight size={12} />
                  )}
                  {category.title}
                </button>

                <AnimatePresence>
                  {expandedCategories.has(category.id) && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.15 }}
                      className="overflow-hidden"
                    >
                      {category.chapters.map((chapter) => {
                        const isActive = currentChapterId === chapter.id;
                        return (
                          <Link
                            key={chapter.id}
                            href={chapter.id === "what-is-tmc" ? "/" : `/chapter/${chapter.id}`}
                            className={`
                              flex items-center gap-2.5 px-3 py-2 ml-2 rounded-md text-sm no-underline
                              transition-all duration-150
                              ${isActive
                                ? "text-primary bg-accent/80"
                                : "text-muted-foreground hover:text-foreground hover:bg-accent/40"
                              }
                            `}
                          >
                            <ChapterIcon
                              name={chapter.icon}
                              className={`w-4 h-4 flex-shrink-0 ${isActive ? "text-primary" : ""}`}
                            />
                            <span className="truncate">
                              <span className="opacity-50 mr-1" style={{ fontSize: "11px" }}>
                                {String(chapter.number).padStart(2, "0")}
                              </span>
                              {chapter.title}
                            </span>
                            {isActive && (
                              <motion.div
                                layoutId="sidebar-indicator"
                                className="absolute left-0 w-0.5 h-5 rounded-r"
                                style={{ background: "oklch(0.78 0.12 80)" }}
                              />
                            )}
                          </Link>
                        );
                      })}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ))}
          </nav>

          {/* Sidebar Footer */}
          <div className="px-5 py-4 border-t border-border/40">
            <p className="text-[11px] leading-relaxed" style={{ color: "oklch(0.42 0.015 260)" }}>
              Player guide for Too Many Coins.
              <br />
              <a
                href="https://github.com/TheRealTwizzy/too-many-coins-api"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 mt-1 hover:text-primary transition-colors"
                style={{ color: "oklch(0.55 0.02 260)" }}
              >
                View on GitHub <ExternalLink size={10} />
              </a>
            </p>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 min-w-0">
          {children}
        </main>
      </div>
    </div>
  );
}
