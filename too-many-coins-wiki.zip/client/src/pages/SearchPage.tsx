/**
 * SearchPage — Full-text search across all wiki content
 * "Coin Forge" Dark Industrial Aesthetic — Player-Facing Wiki
 */
import { useState, useEffect, useMemo } from "react";
import { Link, useSearch } from "wouter";
import { motion } from "framer-motion";
import { Search, ChevronRight, FileText } from "lucide-react";
import WikiLayout from "@/components/WikiLayout";
import { searchWiki } from "@/lib/wikiData";

export default function SearchPage() {
  const searchParams = useSearch();
  const urlQuery = new URLSearchParams(searchParams).get("q") || "";
  const [query, setQuery] = useState(urlQuery);

  useEffect(() => {
    setQuery(urlQuery);
  }, [urlQuery]);

  const results = useMemo(() => {
    if (query.trim().length < 2) return [];
    return searchWiki(query.trim());
  }, [query]);

  const getChapterHref = (chapterId: string, sectionId: string) =>
    chapterId === "what-is-tmc" ? `/#${sectionId}` : `/chapter/${chapterId}#${sectionId}`;

  return (
    <WikiLayout>
      <div className="px-6 lg:px-10 py-8 max-w-4xl">
        {/* Search Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold mb-4 gold-gradient-text" style={{ fontFamily: "var(--font-heading)" }}>
            Search Wiki
          </h1>
          <div className="flex items-center gap-3 p-3 rounded-lg border border-border/60 bg-muted/20">
            <Search size={18} className="text-muted-foreground flex-shrink-0" />
            <input
              type="text"
              placeholder="Search across all topics..."
              value={query}
              onChange={e => setQuery(e.target.value)}
              className="bg-transparent text-base outline-none w-full placeholder:text-muted-foreground"
              autoFocus
            />
          </div>
        </div>

        {/* Results */}
        {query.trim().length >= 2 && (
          <div className="mb-4">
            <p className="text-sm text-muted-foreground">
              {results.length} result{results.length !== 1 ? "s" : ""} for "<span className="text-primary">{query}</span>"
            </p>
          </div>
        )}

        <div className="space-y-3">
          {results.map((result, i) => (
            <motion.div
              key={`${result.chapter.id}-${result.section.id}`}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
            >
              <Link
                href={getChapterHref(result.chapter.id, result.section.id)}
                className="block p-4 rounded-lg border border-border/40 hover:border-primary/30 transition-all no-underline hover:bg-accent/20 group"
              >
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-1.5">
                  <FileText size={12} />
                  <span>Chapter {String(result.chapter.number).padStart(2, "0")}</span>
                  <ChevronRight size={10} />
                  <span className="group-hover:text-primary transition-colors">{result.chapter.title}</span>
                </div>
                <h3 className="text-sm font-medium text-foreground group-hover:text-primary transition-colors mb-1" style={{ fontFamily: "var(--font-heading)" }}>
                  {result.section.title}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: "oklch(0.55 0.015 260)" }}>
                  {result.snippet.replace(/\*\*/g, "").replace(/`/g, "")}
                </p>
              </Link>
            </motion.div>
          ))}
        </div>

        {query.trim().length >= 2 && results.length === 0 && (
          <div className="text-center py-16">
            <Search size={40} className="mx-auto mb-4" style={{ color: "oklch(0.30 0.015 260)" }} />
            <h3 className="text-lg font-medium mb-2" style={{ fontFamily: "var(--font-heading)", color: "oklch(0.55 0.02 260)" }}>
              No results found
            </h3>
            <p className="text-sm text-muted-foreground">
              Try different keywords or browse the topics in the sidebar.
            </p>
          </div>
        )}

        {query.trim().length < 2 && (
          <div className="text-center py-16">
            <Search size={40} className="mx-auto mb-4" style={{ color: "oklch(0.30 0.015 260)" }} />
            <h3 className="text-lg font-medium mb-2" style={{ fontFamily: "var(--font-heading)", color: "oklch(0.55 0.02 260)" }}>
              Start typing to search
            </h3>
            <p className="text-sm text-muted-foreground">
              Search across all topics in the player guide.
            </p>
          </div>
        )}
      </div>
    </WikiLayout>
  );
}
