/**
 * Home — Landing page for the player-facing Too Many Coins Wiki
 * "Coin Forge" Dark Industrial Aesthetic
 */
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Coins, Clock, Trophy, Shield, ChevronRight,
  BookOpen, Compass, Sparkles, ArrowLeftRight, Lightbulb, Users
} from "lucide-react";
import WikiLayout from "@/components/WikiLayout";
import MarkdownRenderer from "@/components/MarkdownRenderer";
import { getChapter, wikiCategories } from "@/lib/wikiData";

const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663454561774/PWroUmiKVgj2u7UGqxPdaQ/hero-coins-QmGhLoL58E7tkWcwncqES6.webp";

const quickLinks = [
  { icon: Compass, title: "Your First Season", desc: "New player guide", href: "/chapter/first-season" },
  { icon: Coins, title: "Coins & Stars", desc: "How resources work", href: "/chapter/resources-guide" },
  { icon: Sparkles, title: "Sigils & Boosts", desc: "Power-ups explained", href: "/chapter/sigils-guide" },
  { icon: Clock, title: "How Seasons Work", desc: "Season structure & timing", href: "/chapter/seasons-guide" },
  { icon: Trophy, title: "Leaderboards", desc: "Rankings & competition", href: "/chapter/leaderboards" },
  { icon: Lightbulb, title: "Strategy Guide", desc: "Tips & advanced play", href: "/chapter/strategy-guide" },
];

const fadeUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4, ease: [0, 0, 0.2, 1] as const }
};

export default function Home() {
  const introChapter = getChapter("what-is-tmc");

  return (
    <WikiLayout>
      {/* Hero Section */}
      <div className="relative overflow-hidden" style={{ minHeight: "340px" }}>
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${HERO_IMG})` }}
        />
        <div className="absolute inset-0" style={{
          background: "linear-gradient(to bottom, oklch(0.11 0.008 260 / 0.55), oklch(0.11 0.008 260 / 0.85) 60%, oklch(0.11 0.008 260))"
        }} />
        <div className="relative z-10 px-6 lg:px-10 py-16 lg:py-20 max-w-4xl">
          <motion.div {...fadeUp}>
            <div className="flex items-center gap-2 mb-4">
              <div className="h-px flex-1 max-w-12" style={{ background: "oklch(0.78 0.12 80)" }} />
              <span className="text-xs uppercase tracking-[0.2em] font-medium" style={{ color: "oklch(0.78 0.12 80)" }}>
                Player Guide
              </span>
            </div>
            <h1
              className="text-4xl lg:text-5xl font-bold mb-4 leading-tight"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              <span className="gold-gradient-text">Too Many Coins</span>
              <br />
              <span style={{ color: "oklch(0.80 0.015 260)" }}>Wiki</span>
            </h1>
            <p className="text-base lg:text-lg leading-relaxed max-w-2xl" style={{ color: "oklch(0.65 0.015 260)" }}>
              Your complete guide to mastering the season-based economic competition.
              Learn the mechanics, plan your strategy, and climb the leaderboards.
            </p>
          </motion.div>
        </div>
      </div>

      {/* Quick Links Grid */}
      <div className="px-6 lg:px-10 py-10 border-b border-border/40">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <h2 className="text-sm uppercase tracking-widest font-semibold mb-6" style={{ color: "oklch(0.55 0.02 260)", fontFamily: "var(--font-heading)" }}>
            Quick Navigation
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {quickLinks.map((link, i) => (
              <Link key={link.href} href={link.href}>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + i * 0.05 }}
                  className="group flex items-center gap-3 p-4 rounded-lg border border-border/50 hover:border-primary/30 transition-all duration-200 hover:bg-accent/30"
                  style={{ cursor: "pointer" }}
                >
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: "oklch(0.18 0.015 260)" }}>
                    <link.icon size={18} className="text-primary" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-foreground group-hover:text-primary transition-colors" style={{ fontFamily: "var(--font-heading)" }}>
                      {link.title}
                    </div>
                    <div className="text-xs text-muted-foreground truncate">{link.desc}</div>
                  </div>
                  <ChevronRight size={14} className="ml-auto text-muted-foreground/40 group-hover:text-primary/60 transition-colors flex-shrink-0" />
                </motion.div>
              </Link>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Key Concepts */}
      <div className="px-6 lg:px-10 py-10 border-b border-border/40">
        <h2 className="text-sm uppercase tracking-widest font-semibold mb-6" style={{ color: "oklch(0.55 0.02 260)", fontFamily: "var(--font-heading)" }}>
          What You Need to Know
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { icon: Shield, title: "Fair Competition", desc: "No pay-to-win, no hidden advantages. Every player starts each season on equal footing." },
            { icon: Clock, title: "Strategy Over Grinding", desc: "Smart timing beats constant activity. Short, well-planned sessions can outperform hours of idle play." },
            { icon: Coins, title: "Meaningful Choices", desc: "Every Coin earned and Star spent has weight. Your decisions are permanent — and that's what makes them exciting." },
            { icon: Trophy, title: "Layered Prestige", desc: "Compete for seasonal placement, yearly rankings, and permanent badges that showcase your achievements." },
          ].map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.05 }}
              className="p-5 rounded-lg"
              style={{ background: "oklch(0.14 0.01 260)", borderLeft: "3px solid oklch(0.78 0.12 80 / 0.4)" }}
            >
              <div className="flex items-center gap-2 mb-2">
                <item.icon size={16} className="text-primary" />
                <h3 className="text-sm font-semibold" style={{ fontFamily: "var(--font-heading)", color: "oklch(0.88 0.08 80)" }}>
                  {item.title}
                </h3>
              </div>
              <p className="text-sm leading-relaxed" style={{ color: "oklch(0.65 0.015 260)" }}>
                {item.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Introduction Chapter Content */}
      {introChapter && (
        <div className="px-6 lg:px-10 py-10 max-w-4xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs uppercase tracking-widest font-medium" style={{ color: "oklch(0.50 0.02 260)" }}>
              Chapter 01
            </span>
          </div>
          <h2 className="text-2xl font-bold mb-8 gold-gradient-text" style={{ fontFamily: "var(--font-heading)" }}>
            What Is Too Many Coins?
          </h2>
          {introChapter.sections.map((section) => (
            <div key={section.id} id={section.id} className="mb-10 scroll-mt-20">
              <h3 className="text-lg font-semibold mb-4" style={{ fontFamily: "var(--font-heading)", color: "oklch(0.82 0.12 80)" }}>
                {section.title}
              </h3>
              <MarkdownRenderer content={section.content} />
            </div>
          ))}
        </div>
      )}

      {/* All Chapters Index */}
      <div className="px-6 lg:px-10 py-10 border-t border-border/40">
        <h2 className="text-sm uppercase tracking-widest font-semibold mb-6" style={{ color: "oklch(0.55 0.02 260)", fontFamily: "var(--font-heading)" }}>
          Browse All Topics
        </h2>
        <div className="space-y-6">
          {wikiCategories.map(category => (
            <div key={category.id}>
              <h3 className="text-xs uppercase tracking-widest font-medium mb-3" style={{ color: "oklch(0.45 0.02 260)" }}>
                {category.title}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {category.chapters.map(ch => (
                  <Link
                    key={ch.id}
                    href={ch.id === "what-is-tmc" ? "/" : `/chapter/${ch.id}`}
                    className="flex items-start gap-3 p-3 rounded-lg hover:bg-accent/30 transition-colors no-underline group"
                  >
                    <span className="text-xs font-mono mt-0.5" style={{ color: "oklch(0.45 0.02 260)" }}>
                      {String(ch.number).padStart(2, "0")}
                    </span>
                    <div>
                      <div className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                        {ch.title}
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">
                        {ch.description}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <footer className="px-6 lg:px-10 py-8 border-t border-border/40">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Coins size={16} className="text-primary" />
            <span className="text-xs" style={{ color: "oklch(0.45 0.02 260)" }}>
              Too Many Coins Wiki — Player Guide
            </span>
          </div>
          <a
            href="https://github.com/TheRealTwizzy/too-many-coins-api"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs flex items-center gap-1 hover:text-primary transition-colors"
            style={{ color: "oklch(0.45 0.02 260)" }}
          >
            GitHub <ChevronRight size={12} />
          </a>
        </div>
      </footer>
    </WikiLayout>
  );
}
