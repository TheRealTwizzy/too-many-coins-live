/**
 * Chapter — Renders a single wiki chapter with its sections
 * "Coin Forge" Dark Industrial Aesthetic — Player-Facing Wiki
 */
import { useParams, Link } from "wouter";
import { useEffect, useState, useRef } from "react";
import { motion } from "framer-motion";
import { ChevronRight, ChevronLeft, ArrowUp } from "lucide-react";
import WikiLayout from "@/components/WikiLayout";
import MarkdownRenderer from "@/components/MarkdownRenderer";
import { getChapter, getAllChapters } from "@/lib/wikiData";

export default function ChapterPage() {
  const params = useParams<{ id: string }>();
  const chapter = getChapter(params.id || "");
  const allChapters = getAllChapters();
  const [activeSection, setActiveSection] = useState<string>("");
  const [showScrollTop, setShowScrollTop] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  // Track active section on scroll
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);

      if (!chapter) return;
      const sections = chapter.sections.map(s => ({
        id: s.id,
        el: document.getElementById(s.id)
      })).filter(s => s.el);

      for (let i = sections.length - 1; i >= 0; i--) {
        const rect = sections[i].el!.getBoundingClientRect();
        if (rect.top <= 120) {
          setActiveSection(sections[i].id);
          return;
        }
      }
      if (sections.length > 0) setActiveSection(sections[0].id);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, [chapter]);

  // Scroll to top on chapter change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, [params.id]);

  if (!chapter) {
    return (
      <WikiLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-2 gold-gradient-text" style={{ fontFamily: "var(--font-heading)" }}>
              Page Not Found
            </h1>
            <p className="text-muted-foreground mb-4">The requested page does not exist.</p>
            <Link href="/" className="text-primary hover:underline text-sm">
              Return to Home
            </Link>
          </div>
        </div>
      </WikiLayout>
    );
  }

  const chapterIndex = allChapters.findIndex(c => c.id === chapter.id);
  const prevChapter = chapterIndex > 0 ? allChapters[chapterIndex - 1] : null;
  const nextChapter = chapterIndex < allChapters.length - 1 ? allChapters[chapterIndex + 1] : null;

  const getChapterHref = (ch: { id: string }) =>
    ch.id === "what-is-tmc" ? "/" : `/chapter/${ch.id}`;

  return (
    <WikiLayout>
      <div className="flex">
        {/* Main Content */}
        <div className="flex-1 min-w-0 px-6 lg:px-10 py-8 max-w-4xl" ref={contentRef}>
          {/* Breadcrumb */}
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-6">
            <Link href="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight size={12} />
            <span style={{ color: "oklch(0.65 0.015 260)" }}>{chapter.title}</span>
          </div>

          {/* Chapter Header */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs uppercase tracking-widest font-medium" style={{ color: "oklch(0.50 0.02 260)" }}>
                Chapter {String(chapter.number).padStart(2, "0")}
              </span>
            </div>
            <h1 className="text-3xl lg:text-4xl font-bold mb-3 gold-gradient-text" style={{ fontFamily: "var(--font-heading)" }}>
              {chapter.title}
            </h1>
            <p className="text-base mb-8" style={{ color: "oklch(0.60 0.015 260)" }}>
              {chapter.description}
            </p>
            <div className="h-px mb-10" style={{ background: "linear-gradient(to right, oklch(0.78 0.12 80 / 0.3), transparent)" }} />
          </motion.div>

          {/* Sections */}
          {chapter.sections.map((section, i) => (
            <motion.div
              key={section.id}
              id={section.id}
              className="mb-12 scroll-mt-20"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05, duration: 0.3 }}
            >
              <h2 className="text-xl lg:text-2xl font-semibold mb-5" style={{ fontFamily: "var(--font-heading)", color: "oklch(0.82 0.12 80)" }}>
                {section.title}
              </h2>
              <MarkdownRenderer content={section.content} />
            </motion.div>
          ))}

          {/* Chapter Navigation */}
          <div className="flex items-stretch gap-4 mt-16 pt-8 border-t border-border/40">
            {prevChapter ? (
              <Link
                href={getChapterHref(prevChapter)}
                className="flex-1 group p-4 rounded-lg border border-border/50 hover:border-primary/30 transition-all no-underline hover:bg-accent/20"
              >
                <div className="flex items-center gap-1 text-xs text-muted-foreground mb-1">
                  <ChevronLeft size={12} />
                  Previous
                </div>
                <div className="text-sm font-medium text-foreground group-hover:text-primary transition-colors" style={{ fontFamily: "var(--font-heading)" }}>
                  {prevChapter.title}
                </div>
              </Link>
            ) : <div className="flex-1" />}
            {nextChapter ? (
              <Link
                href={getChapterHref(nextChapter)}
                className="flex-1 group p-4 rounded-lg border border-border/50 hover:border-primary/30 transition-all no-underline text-right hover:bg-accent/20"
              >
                <div className="flex items-center justify-end gap-1 text-xs text-muted-foreground mb-1">
                  Next
                  <ChevronRight size={12} />
                </div>
                <div className="text-sm font-medium text-foreground group-hover:text-primary transition-colors" style={{ fontFamily: "var(--font-heading)" }}>
                  {nextChapter.title}
                </div>
              </Link>
            ) : <div className="flex-1" />}
          </div>

          {/* Footer */}
          <div className="mt-12 pb-8 text-center">
            <p className="text-xs" style={{ color: "oklch(0.40 0.015 260)" }}>
              Too Many Coins Wiki — Player Guide
            </p>
          </div>
        </div>

        {/* Right Rail — Table of Contents */}
        <aside className="hidden xl:block w-56 flex-shrink-0 py-8 pr-6">
          <div className="sticky top-20">
            <h4 className="text-xs uppercase tracking-widest font-semibold mb-3" style={{ color: "oklch(0.45 0.02 260)", fontFamily: "var(--font-heading)" }}>
              On this page
            </h4>
            <nav className="space-y-0.5">
              {chapter.sections.map(section => (
                <a
                  key={section.id}
                  href={`#${section.id}`}
                  className={`
                    block text-xs py-1.5 pl-3 border-l-2 transition-all duration-150 no-underline
                    ${activeSection === section.id
                      ? "border-primary text-primary"
                      : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
                    }
                  `}
                >
                  {section.title}
                </a>
              ))}
            </nav>
          </div>
        </aside>
      </div>

      {/* Scroll to top */}
      {showScrollTop && (
        <motion.button
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-6 right-6 z-50 w-10 h-10 rounded-full flex items-center justify-center border border-border/60 shadow-lg transition-colors hover:border-primary/40"
          style={{ background: "oklch(0.16 0.01 260)" }}
        >
          <ArrowUp size={16} className="text-primary" />
        </motion.button>
      )}
    </WikiLayout>
  );
}
